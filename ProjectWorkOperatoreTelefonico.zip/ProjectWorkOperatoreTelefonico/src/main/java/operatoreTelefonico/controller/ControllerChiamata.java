package operatoreTelefonico.controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import operatoreTelefonico.model.Chiamata;
import operatoreTelefonico.service.ChiamataService;

@RestController
@RequestMapping(path="/chiamata")
public class ControllerChiamata {

	private final ChiamataService chiamataService;
	
	public ControllerChiamata(ChiamataService chiamataService) {
		this.chiamataService = chiamataService;
	}
	
	@GetMapping(path="/recuperaChiamata/{idChiamata}")
	public String recuperaChiamata(@PathVariable("idChiamata") Integer idChiamata) {
		return chiamataService.recuperaChiamata(idChiamata);
	}
	
	@GetMapping(path="/listaChiamate")
	public Iterable<Chiamata> recuperaListaChiamate() {
		Iterable<Chiamata> listaChiamate = chiamataService.recuperaListaChiamate();
		return listaChiamate;
	}
	
	@PostMapping(path="/inserisciChiamata/{idAbbonamento}")
	public String inserisciChiamata(@RequestBody Chiamata chiamata, @PathVariable("idAbbonamento") Integer idAbbonamento) {
		return chiamataService.inserisciChiamata(chiamata, idAbbonamento);	
	}

}
