package operatoreTelefonico.controller;

import org.springframework.web.bind.annotation.*;

import operatoreTelefonico.model.Abbonamento;
import operatoreTelefonico.service.AbbonamentoService;

@RestController
@RequestMapping(path="/abbonamento")
public class ControllerAbbonamento {

	private final AbbonamentoService abbonamentoService;
	
	public ControllerAbbonamento(AbbonamentoService abbonamentoService) {
		this.abbonamentoService = abbonamentoService;
	}
	
	@GetMapping(path="/recuperaAbbonamento/{idAbbonamento}")
	public String recuperaAbbonamento(@PathVariable("idAbbonamento") Integer idAbbonamento) {
		return abbonamentoService.recuperaAbbonamento(idAbbonamento);
	}
	
	@GetMapping(path="/listaAbbonamenti")
	public Iterable<Abbonamento> recuperaListaAbbonamenti() {
		Iterable<Abbonamento> listaAbbonamenti = abbonamentoService.recuperaListaAbbonamenti();
		return listaAbbonamenti;
	}
	
	@PostMapping(path="/inserisciAbbonamento/{idCliente}")
	public String inserisciAbbonamento(@RequestBody Abbonamento abbonamento, @PathVariable("idCliente") Integer idCliente) {
		return abbonamentoService.inserisciAbbonamento(abbonamento, idCliente);	
	}
	
	@PutMapping(path="/aggiornaAbbonamento/{idAbbonamento}")
	public String aggiornaAbbonamento(@PathVariable("idAbbonamento") Integer idAbbonamento, @RequestBody Abbonamento abbonamento) {
		return abbonamentoService.aggiornaAbbonamento(idAbbonamento, abbonamento);	
	}
	
	@DeleteMapping(path="/eliminaAbbonamento/{idAbbonamento}")
	public String eliminaAbbonamento(@PathVariable("idAbbonamento") Integer idAbbonamento) {
		return abbonamentoService.eliminaAbbonamento(idAbbonamento);	
	}
}
