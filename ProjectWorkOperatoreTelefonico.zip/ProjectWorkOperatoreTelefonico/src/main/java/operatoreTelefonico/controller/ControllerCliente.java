package operatoreTelefonico.controller;

import org.springframework.web.bind.annotation.*;

import operatoreTelefonico.model.Cliente;
import operatoreTelefonico.service.ClienteService;

@RestController
@RequestMapping(path="/cliente")
public class ControllerCliente {
	
	private final ClienteService clienteService;
	
	public ControllerCliente(ClienteService clienteService) {
		this.clienteService = clienteService;
	}
	
	@GetMapping(path="/recuperaCliente/{idCliente}")
	public String recuperaCliente(@PathVariable("idCliente") Integer idCliente) {
		return clienteService.recuperaCliente(idCliente);
	}
	
	@GetMapping(path="/listaClienti")
	public Iterable<Cliente> recuperaListaClienti() {
		Iterable<Cliente> listaClienti = clienteService.recuperaListaClienti();
		return listaClienti;
	}
	
	@PostMapping(path="/inserisciCliente")
	public String inserisciCliente(@RequestBody Cliente cliente) {
		return clienteService.inserisciCliente(cliente);	
	}
	
	@PutMapping(path="/aggiornaCliente/{idCliente}")
	public String aggiornaCliente(@PathVariable("idCliente") Integer idCliente, @RequestBody Cliente cliente) {
		return clienteService.aggiornaCliente(idCliente, cliente);	
	}
	
	@DeleteMapping(path="/eliminaCliente/{idCliente}")
	public String eliminaCliente(@PathVariable("idCliente") Integer idCliente) {
		return clienteService.eliminaCliente(idCliente);	
	}
}
