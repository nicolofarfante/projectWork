package operatoreTelefonico.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import operatoreTelefonico.model.Report;
import operatoreTelefonico.service.ReportService;

@RestController
@RequestMapping(path="/report")
public class ControllerReport {
	
	private final ReportService reportService;
	
	public ControllerReport(ReportService reportService) {
		this.reportService = reportService;
	}
	
	@GetMapping
	public Long generaReport(@RequestBody Report report) {
		Long durata = reportService.getTotaleMinutiChiamate(report.getNumeroTelefono(), 
				report.getDataInizio(), report.getDataFine());
		return durata;
	}
}
