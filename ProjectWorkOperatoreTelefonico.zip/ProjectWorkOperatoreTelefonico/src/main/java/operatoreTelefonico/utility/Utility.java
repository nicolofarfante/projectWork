package operatoreTelefonico.utility;

import java.time.Duration;
import java.time.LocalDateTime;

public class Utility {
	
	public static Long durationSeconds(LocalDateTime dateCallStart, LocalDateTime dateCallEnd) {
        LocalDateTime toDateTime = dateCallEnd;
        LocalDateTime fromDateTime = dateCallStart;

        long[] time = getTime(fromDateTime, toDateTime);

        Long secondsHours = time[0] * (60*60);
        Long secondsMinutes = time[1] * 60;
        Long secondsSeconds = time[2];

        return secondsHours + secondsMinutes + secondsSeconds;
	}
	
	private static long[] getTime(LocalDateTime dob, LocalDateTime now) {
        LocalDateTime today = LocalDateTime.of(now.getYear(),
                now.getMonthValue(), now.getDayOfMonth(), dob.getHour(), dob.getMinute(), dob.getSecond());
        Duration duration = Duration.between(today, now);

        long seconds = duration.getSeconds();

        long hours = seconds / 60;
        long minutes = ((seconds % 3600) / 60);
        long secs = (seconds % 60);

        return new long[]{hours, minutes, secs};
	}
}
