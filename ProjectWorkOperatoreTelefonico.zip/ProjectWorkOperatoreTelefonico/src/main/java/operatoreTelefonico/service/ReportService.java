package operatoreTelefonico.service;

import java.time.LocalDateTime;

public interface ReportService {

	public Long getTotaleMinutiChiamate(String numeroTelefono, 
			LocalDateTime dataInizio, LocalDateTime dataFine);
}
