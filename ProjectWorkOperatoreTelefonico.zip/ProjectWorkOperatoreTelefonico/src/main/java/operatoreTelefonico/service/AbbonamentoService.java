package operatoreTelefonico.service;

import operatoreTelefonico.model.Abbonamento;

public interface AbbonamentoService {

	String inserisciAbbonamento(Abbonamento abbonamento, Integer idCliente);
	String eliminaAbbonamento(Integer idAbbonamento);
	String aggiornaAbbonamento(Integer idAbbonamento, Abbonamento abbonamento);
	String recuperaAbbonamento(Integer idAbbonamento);
	Iterable<Abbonamento> recuperaListaAbbonamenti();
}
