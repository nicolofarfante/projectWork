package operatoreTelefonico.service;

import operatoreTelefonico.model.Chiamata;

public interface ChiamataService {

	String inserisciChiamata(Chiamata chiamata, Integer idAbbonamento);
	String recuperaChiamata(Integer idChiamata);
	Iterable<Chiamata> recuperaListaChiamate();
}
