package operatoreTelefonico.service.implementazioneServices;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import operatoreTelefonico.model.Abbonamento;
import operatoreTelefonico.model.Cliente;
import operatoreTelefonico.repository.AbbonamentoRepository;
import operatoreTelefonico.repository.ClienteRepository;
import operatoreTelefonico.service.AbbonamentoService;

@Service
public class AbbonamentoServiceImpl implements AbbonamentoService{
	
	@Autowired
	AbbonamentoRepository abbonamentoRepo;
	@Autowired
	ClienteRepository clienteRepo;

	@Override
	public String inserisciAbbonamento(Abbonamento abbonamento, Integer idCliente) {
		Cliente cl = clienteRepo.findById(idCliente).orElse(null);
		if(cl != null) {
			Abbonamento abb = abbonamentoRepo.save(abbonamento);
			return "Abbonamento inserito correttamente: " + abb.toString();
		}
		else {
			return "Abbonamento non inserito";
		}
	}

	@Override
	public String eliminaAbbonamento(Integer idAbbonamento) {
		Abbonamento abb = abbonamentoRepo.findByIdAbbonamento(idAbbonamento);
		if(abb != null) {
			abbonamentoRepo.delete(abb);
			return "Abbonamento rimosso con successo";
		}
		return "Nessun abbonamento presente con l'ID selezionato";
	}

	@Override
	public String aggiornaAbbonamento(Integer idAbbonamento, Abbonamento abbonamento) {
		Abbonamento abb = abbonamentoRepo.findByIdAbbonamento(idAbbonamento);
		if(abb != null) {
			abb.setDataAttivazione(abbonamento.getDataAttivazione());
			abb.setDataCessazione(abbonamento.getDataCessazione());
			abb.setDataSospensione(abbonamento.getDataSospensione());
			abb.setDataRientro(abbonamento.getDataRientro());
			abb.setNumeroTelefono(abbonamento.getNumeroTelefono());
			abb.setTipologiaAbbonamento(abbonamento.getTipologiaAbbonamento());
			abbonamentoRepo.save(abb);
			return "Aggiornamento completato: " + abb.toString();
		}
		return "Aggiornamento non riuscito";
	}

	@Override
	public String recuperaAbbonamento(Integer idAbbonamento) {
		Abbonamento abb = abbonamentoRepo.findByIdAbbonamento(idAbbonamento);
		if(abb != null) {
			return abb.toString();
		}
		return "Nessun abbonamento presente con l'ID selezionato";
	}

	@Override
	public Iterable<Abbonamento> recuperaListaAbbonamenti() {
		Iterable<Abbonamento> listaAbbonamenti = abbonamentoRepo.findAll();
		return listaAbbonamenti;
	}

}
