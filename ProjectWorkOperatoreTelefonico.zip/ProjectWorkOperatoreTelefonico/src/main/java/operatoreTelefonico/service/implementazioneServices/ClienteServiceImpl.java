package operatoreTelefonico.service.implementazioneServices;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import operatoreTelefonico.model.Cliente;
import operatoreTelefonico.repository.ClienteRepository;
import operatoreTelefonico.service.ClienteService;

@Service
public class ClienteServiceImpl implements ClienteService{
	
	@Autowired
	ClienteRepository clienteRepo;

	@Override
	public String inserisciCliente(Cliente cliente) {
		Cliente cl = clienteRepo.save(cliente);
		return "Cliente inserito correttamente: " + cl.toString();
	}

	@Override
	public String eliminaCliente(Integer idCliente) {
		Cliente cl = clienteRepo.findByIdCliente(idCliente);
		if(cl != null) {
			clienteRepo.delete(cl);
			return "Cliente rimosso con successo";
		}
		return "Nessun cliente presente con l'ID selezionato";
	}

	@Override
	public String aggiornaCliente(Integer idCliente, Cliente cliente) {
		Cliente cl = clienteRepo.findByIdCliente(idCliente);
		if(cl != null) {
			cl.setNome(cliente.getNome());
			cl.setCognome(cliente.getCognome());
			cl.setDataNascita(cliente.getDataNascita());
			clienteRepo.save(cl);
			return "Aggiornamento completato: " + cl.toString();
		}
		return "Aggiornamento non riuscito";
	}

	@Override
	public String recuperaCliente(Integer idCliente) {
		Cliente cl = clienteRepo.findByIdCliente(idCliente);
		if(cl != null) {
			return cl.toString();
		}
		return "Nessun cliente presente con l'ID selezionato";
	}

	@Override
	public Iterable<Cliente> recuperaListaClienti() {
		Iterable<Cliente> listaClienti = clienteRepo.findAll();
		return listaClienti;
	}
	
}
