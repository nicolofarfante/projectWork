package operatoreTelefonico.service.implementazioneServices;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import operatoreTelefonico.model.Abbonamento;
import operatoreTelefonico.model.Chiamata;
import operatoreTelefonico.repository.AbbonamentoRepository;
import operatoreTelefonico.repository.ChiamataRepository;
import operatoreTelefonico.service.ChiamataService;

@Service
public class ChiamataServiceImpl implements ChiamataService{

	@Autowired
	ChiamataRepository chiamataRepo;
	@Autowired
	AbbonamentoRepository abbonamentoRepo;

	@Override
	public String inserisciChiamata(Chiamata chiamata, Integer idAbbonamento) {
		Abbonamento abb = abbonamentoRepo.findById(idAbbonamento).orElse(null);
		Chiamata ch = new Chiamata();
		ch.setDataInizio(chiamata.getDataInizio());
		ch.setDataFine(chiamata.getDataFine());
		ch.setAbbonamento(abb);
		chiamataRepo.save(ch);
		return "Chiamata inserita correttamente: " + ch.toString();
	}

	@Override
	public String recuperaChiamata(Integer idChiamata) {
		Chiamata ch = chiamataRepo.findByIdChiamata(idChiamata);
		//ch.getAbbonamento().
		if(ch != null) {
			return ch.toString();
		}
		return "Nessuna chiamata presente con l'ID selezionato";
	}

	@Override
	public Iterable<Chiamata> recuperaListaChiamate() {
		Iterable<Chiamata> listaChiamate = chiamataRepo.findAll();
		return listaChiamate;
	}

}
