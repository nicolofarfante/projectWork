package operatoreTelefonico.service.implementazioneServices;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import operatoreTelefonico.model.Chiamata;
import operatoreTelefonico.repository.ChiamataRepository;
import operatoreTelefonico.service.ReportService;
import operatoreTelefonico.utility.Utility;

@Service
public class ReportServiceImpl implements ReportService{

	@Autowired
	ChiamataRepository chiamataRepo;
	
	public Long getTotaleMinutiChiamate(String numeroTelefono, LocalDateTime dataInizio, LocalDateTime dataFine) {
		List <Chiamata> listaChiamate = chiamataRepo.findByDataInizioIsBetween(dataInizio, dataFine);
		Long durata = (long) 0;
		for(Chiamata ch: listaChiamate) {
			if(ch.getAbbonamento().getNumeroTelefono().equals(numeroTelefono)) {
				durata += Utility.durationSeconds(dataInizio, dataFine);
			}
		}
		return durata;
	}
}
