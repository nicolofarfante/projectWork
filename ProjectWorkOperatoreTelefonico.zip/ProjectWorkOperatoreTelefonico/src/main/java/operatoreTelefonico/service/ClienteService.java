package operatoreTelefonico.service;

import operatoreTelefonico.model.Cliente;

public interface ClienteService {

	String inserisciCliente(Cliente cliente);
	String eliminaCliente(Integer idCliente);
	String aggiornaCliente(Integer idCliente, Cliente cliente);
	String recuperaCliente(Integer idCliente);
	Iterable<Cliente> recuperaListaClienti();
}
