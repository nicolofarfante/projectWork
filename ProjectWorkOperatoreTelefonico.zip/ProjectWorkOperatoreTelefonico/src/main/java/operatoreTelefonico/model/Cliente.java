package operatoreTelefonico.model;

import java.time.LocalDate;

import javax.persistence.*;
import javax.validation.constraints.*;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name="clienti")
public class Cliente {

	@Id
	@Column(name="id_cliente")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer idCliente;
	
	@Column(name="nome")
	@NotBlank(message="Campo obbligatorio")
	private String nome;
	
	@Column(name="cognome")
	@NotBlank(message="Campo obbligatorio")
	private String cognome;
	
	@Column(name="data_nascita")
	@DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
	@NotNull(message="Campo obbligatorio")
	private LocalDate dataNascita;

	public Cliente() {
		super();
	}

	public Cliente(String nome, String cognome, LocalDate dataNascita) {
		super();
		this.nome = nome;
		this.cognome = cognome;
		this.dataNascita = dataNascita;
	}

	public Integer getIdCliente() {
		return idCliente;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCognome() {
		return cognome;
	}

	public void setCognome(String cognome) {
		this.cognome = cognome;
	}

	public LocalDate getDataNascita() {
		return dataNascita;
	}

	public void setDataNascita(LocalDate dataNascita) {
		this.dataNascita = dataNascita;
	}

	@Override
	public String toString() {
		return "Cliente [idCliente=" + idCliente + ", nome=" + nome + ", cognome=" + cognome + ", dataNascita="
				+ dataNascita + "]";
	}
	
	
}
