package operatoreTelefonico.model;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;


@Entity
@Table(name="chiamate")
public class Chiamata {

	@Id
	@Column(name="id_chiamata")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer idChiamata;
	
	@Column(name="data_inizio")
	@NotNull(message="Campo obbligatorio")
	private LocalDateTime dataInizio;
	
	@Column(name="data_fine")
	@NotNull(message="Campo obbligatorio")
	private LocalDateTime dataFine;
	
	@ManyToOne
	@JoinColumn(name="id_abbonamento")
	private Abbonamento abbonamento;

	public Chiamata() {
		super();
	}

	public Chiamata(LocalDateTime dataInizio, LocalDateTime dataFine, Abbonamento abbonamento) {
		super();
		this.dataInizio = dataInizio;
		this.dataFine = dataFine;
		this.abbonamento = abbonamento;
	}

	public Integer getIdChiamata() {
		return idChiamata;
	}

	public LocalDateTime getDataInizio() {
		return dataInizio;
	}

	public void setDataInizio(LocalDateTime dataInizio) {
		this.dataInizio = dataInizio;
	}

	public LocalDateTime getDataFine() {
		return dataFine;
	}

	public void setDataFine(LocalDateTime dataFine) {
		this.dataFine = dataFine;
	}

	public Abbonamento getAbbonamento() {
		return abbonamento;
	}

	public void setAbbonamento(Abbonamento abbonamento) {
		this.abbonamento = abbonamento;
	}

	@Override
	public String toString() {
		return "Chiamata [idChiamata=" + idChiamata + ", dataInizio=" + dataInizio + ", dataFine=" + dataFine
				+ ", abbonamento=" + abbonamento + "]";
	}
	
}
