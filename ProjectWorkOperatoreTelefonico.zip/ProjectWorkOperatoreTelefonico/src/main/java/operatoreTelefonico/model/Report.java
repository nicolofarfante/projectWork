package operatoreTelefonico.model;

import java.time.LocalDateTime;

public class Report {

	private String numeroTelefono;
	private LocalDateTime dataInizio;
	private LocalDateTime dataFine;
	public Report() {
		super();
	}
	public Report(String numeroTelefono, LocalDateTime dataInizio, LocalDateTime dataFine) {
		super();
		this.numeroTelefono = numeroTelefono;
		this.dataInizio = dataInizio;
		this.dataFine = dataFine;
	}
	public String getNumeroTelefono() {
		return numeroTelefono;
	}
	public void setNumeroTelefono(String numeroTelefono) {
		this.numeroTelefono = numeroTelefono;
	}
	public LocalDateTime getDataInizio() {
		return dataInizio;
	}
	public void setDataInizio(LocalDateTime dataInizio) {
		this.dataInizio = dataInizio;
	}
	public LocalDateTime getDataFine() {
		return dataFine;
	}
	public void setDataFine(LocalDateTime dataFine) {
		this.dataFine = dataFine;
	}
	
}
