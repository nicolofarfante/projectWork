package operatoreTelefonico.model;

public enum Tipologia {

	MOBILE,
	FISSO;
}
