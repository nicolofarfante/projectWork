package operatoreTelefonico.model;

import java.time.LocalDate;

import javax.persistence.*;
import javax.validation.constraints.*;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;
import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name="abbonamenti")
public class Abbonamento {

	@Id
	@Column(name="id_abbonamento")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer idAbbonamento;
	
	@Column(name="data_attivazione")
	@NotNull(message="Campo obbligatorio")
	@DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
	private LocalDate dataAttivazione;
	
	@Column(name="data_cessazione")
	@DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
	private LocalDate dataCessazione;
	
	@Column(name="data_sospensione")
	@DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
	private LocalDate dataSospensione;
	
	@Column(name="data_rientro")
	@DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
	private LocalDate dataRientro;
	
	@Column(name="numero_telefono")
	@NotNull(message="Campo obbligatorio")
	@Size(max=15, message="Il numero di telefono può contenere massimo 15 cifre")
	private String numeroTelefono;
	
	@Column(name="tipologia")
	@NotNull(message="Campo obbligatorio")
	@Enumerated(EnumType.STRING)
	private Tipologia tipologiaAbbonamento;
	
	@ManyToOne(cascade=CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name="idCliente")
	@OnDelete(action = OnDeleteAction.CASCADE)
	private Cliente cliente;

	public Abbonamento() {
		super();
	}

	public Abbonamento(LocalDate dataAttivazione, LocalDate dataCessazione, LocalDate dataSospensione, 
			LocalDate dataRientro, String numeroTelefono, Tipologia tipologiaAbbonamento, Cliente cliente) {
		super();
		this.dataAttivazione = dataAttivazione;
		this.dataCessazione = dataCessazione;
		this.dataSospensione = dataSospensione;
		this.dataRientro = dataRientro;
		this.numeroTelefono = numeroTelefono;
		this.tipologiaAbbonamento = tipologiaAbbonamento;
		this.cliente = cliente;
	}

	public Cliente getCliente() {
		return cliente;
	}

	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}

	public Integer getIdAbbonamento() {
		return idAbbonamento;
	}

	public LocalDate getDataAttivazione() {
		return dataAttivazione;
	}

	public void setDataAttivazione(LocalDate dataAttivazione) {
		this.dataAttivazione = dataAttivazione;
	}

	public LocalDate getDataCessazione() {
		return dataCessazione;
	}

	public void setDataCessazione(LocalDate dataCessazione) {
		this.dataCessazione = dataCessazione;
	}

	public LocalDate getDataSospensione() {
		return dataSospensione;
	}

	public void setDataSospensione(LocalDate dataSospensione) {
		this.dataSospensione = dataSospensione;
	}

	public LocalDate getDataRientro() {
		return dataRientro;
	}

	public void setDataRientro(LocalDate dataRientro) {
		this.dataRientro = dataRientro;
	}

	public String getNumeroTelefono() {
		return numeroTelefono;
	}

	public void setNumeroTelefono(String numeroTelefono) {
		this.numeroTelefono = numeroTelefono;
	}

	public Tipologia getTipologiaAbbonamento() {
		return tipologiaAbbonamento;
	}

	public void setTipologiaAbbonamento(Tipologia tipologiaAbbonamento) {
		this.tipologiaAbbonamento = tipologiaAbbonamento;
	}
	
}
