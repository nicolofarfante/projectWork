package operatoreTelefonico.repository;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.repository.CrudRepository;

import operatoreTelefonico.model.Chiamata;

public interface ChiamataRepository extends CrudRepository<Chiamata, Integer>{

	Chiamata findByIdChiamata(Integer idChiamata);
	List <Chiamata> findByDataInizioIsBetween(LocalDateTime dataInizio, LocalDateTime dataFine);

}
