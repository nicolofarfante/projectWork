package operatoreTelefonico.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import operatoreTelefonico.model.Abbonamento;

@Repository
public interface AbbonamentoRepository extends CrudRepository<Abbonamento, Integer>{

	Abbonamento findByIdAbbonamento(Integer idAbbonamento);

}
