package operatoreTelefonico;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectWorkOperatoreTelefonicoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectWorkOperatoreTelefonicoApplication.class, args);
	}

}
