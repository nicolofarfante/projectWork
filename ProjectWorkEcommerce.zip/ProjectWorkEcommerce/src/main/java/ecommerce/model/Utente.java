package ecommerce.model;

import javax.persistence.*;
import javax.validation.constraints.*;

@Entity
@Table(name="utenti")
public class Utente {

	@Id
	@Column(name="id_utente")
	@NotNull(message="Campo obbligatorio")
	private int idUtente;
	
	@Column(name="username")
	@NotBlank(message="Campo obbligatorio")
	private String username;
	
	@Column(name="password")
	@NotBlank(message="Campo obbligatorio")
	private String password;
	
	@Column(name="is_admin")
	@NotNull(message="Campo obbligatorio")
	private boolean isAdmin;
	
	public Utente() {
	}
	
	public Utente( String username, String password, boolean isAdmin) {
		this.username = username;
		this.password = password;
		this.isAdmin = isAdmin;
	}

	public int getIdUtente() {
		return idUtente;
	}

	public void setIdutente(int idUtente) {
		this.idUtente = idUtente;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public boolean isAdmin() {
		return isAdmin;
	}

	public void setAdmin(boolean isAdmin) {
		this.isAdmin = isAdmin;
	}

	@Override
	public String toString() {
		return "Utente [id_utente=" + idUtente + ", username=" + username + ", password=" + password + ", isAdmin="
				+ isAdmin + "]";
	}
	
}
