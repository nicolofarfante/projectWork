package ecommerce.model;

import javax.persistence.*;
import javax.validation.constraints.*;

@Entity
@Table(name="acquisti")
public class Acquisto {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
	
	@Column(name="id_acquisto")
	@NotNull(message="Campo obbligatorio")
	private Long idAcquisto;
	
	@ManyToOne
	@JoinColumn(name="id_utente")
	@NotNull(message="Campo obbligatorio")
	private Utente utente;
	
	@ManyToOne
	@JoinColumn(name="id_prodotto")
	@NotNull(message="Campo obbligatorio")
	private Prodotto prodotto;
	
	@Column(name="numero_pezzi")
	@NotNull(message="Campo obbligatorio")
	@Min(value=1)
	private int nPezzi;
	
	@Column(name="prezzo")
	@NotNull(message="Campo obbligatorio")
	private Double totaleAcquisto;

	
	
	public Acquisto() {
	}

	public Acquisto(Utente utente, Prodotto prodotto, int nPezzi, Double totaleAcquisto) {
		this.utente = utente;
		this.prodotto = prodotto;
		this.nPezzi = nPezzi;
		this.totaleAcquisto = totaleAcquisto;
	}

	public Long getIdAcquisto() {
		return idAcquisto;
	}

	public void setIdAcquisto(Long idAcquisto) {
		this.idAcquisto = idAcquisto;
	}

	public Utente getUtente() {
		return utente;
	}

	public void setUtente(Utente utente) {
		this.utente = utente;
	}

	public Prodotto getProdotto() {
		return prodotto;
	}

	public void setProdotto(Prodotto prodotto) {
		this.prodotto = prodotto;
	}

	public int getnPezzi() {
		return nPezzi;
	}

	public void setnPezzi(int nPezzi) {
		this.nPezzi = nPezzi;
	}

	public Double getTotaleAcquisto() {
		return totaleAcquisto;
	}

	public void setTotaleAcquisto(Double totaleAcquisto) {
		this.totaleAcquisto = totaleAcquisto;
	}

	@Override
	public String toString() {
		return "Acquisto [idAcquisto=" + idAcquisto + ", utente=" + utente + ", prodotto=" + prodotto + ", nPezzi="
				+ nPezzi + ", totaleAcquisto=" + totaleAcquisto + "]";
	}
	
}
