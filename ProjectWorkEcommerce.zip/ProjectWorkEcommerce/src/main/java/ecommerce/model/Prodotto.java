package ecommerce.model;

import javax.persistence.*;
import javax.validation.constraints.*;

@Entity
@Table(name="prodotti")
public class Prodotto {

	@Id
	@Column(name="id_prodotto")
	@NotNull(message="Campo obbligatorio")
	private Integer idProdotto;
	
	@Column(name="nome")
	@NotBlank(message="Campo obbligatorio")
	private String nome;
	
	@Column(name="descrizione")
	private String descrizione;
	
	@Column(name="prezzo")
	@NotNull(message="Campo obbligatorio")
	private Double prezzo;

	public Prodotto() {
	}
	
	public Prodotto(String nome, String descrizione, Double prezzo) {
		super();
		this.nome = nome;
		this.descrizione = descrizione;
		this.prezzo = prezzo;
	}

	public Integer getIdProdotto() {
		return idProdotto;
	}

	public void setIdProdotto(Integer idProdotto) {
		this.idProdotto = idProdotto;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getDescrizione() {
		return descrizione;
	}

	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}

	public Double getPrezzo() {
		return prezzo;
	}

	public void setPrezzo(Double prezzo) {
		this.prezzo = prezzo;
	}

	@Override
	public String toString() {
		return "Prodotto [idProdotto=" + idProdotto + ", nome=" + nome + ", descrizione=" + descrizione + ", prezzo="
				+ prezzo + "]";
	}
	
}
