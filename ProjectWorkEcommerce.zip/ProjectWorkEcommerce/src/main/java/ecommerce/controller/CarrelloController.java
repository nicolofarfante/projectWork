package ecommerce.controller;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;

import ecommerce.model.Acquisto;
import ecommerce.model.CriteriUtente;
import ecommerce.model.Prodotto;
import ecommerce.model.Utente;
import ecommerce.repository.AcquistoRepository;
import ecommerce.repository.ProdottoRepository;
import ecommerce.repository.UtenteRepository;

@Controller
public class CarrelloController {

	@Autowired
	UtenteRepository utenteRepo;
	@Autowired
	ProdottoRepository prodottoRepo;
	@Autowired
	AcquistoRepository acquistoRepo;
	
	List<Prodotto> prodotti = new ArrayList<>();
	
	@GetMapping("/inserisciNelCarrello")
	public String inserisciNelCarrello(@Valid @ModelAttribute ("prodotto") Prodotto prodotto, Errors errors, Model model, HttpSession session) {
		if(session.getAttribute("utenteLoggato")==null) {
			model.addAttribute("criteriUtente", new CriteriUtente());
			return "login";
		}
		Prodotto prod = prodottoRepo.findById(prodotto.getIdProdotto()).get();
		prodotti.add(prod);
		session.setAttribute("prodottiNelCarrello", prodotti);
		
		Iterable<Prodotto> prodotti = prodottoRepo.findAll();
		model.addAttribute("prodotti", prodotti);

		model.addAttribute("prodotto", prod);
		return "listinoProdotti";  
	}
	
	@GetMapping("/visualizzaCarrello")
	public String visualizzaCarrello(Model model, HttpSession session) {
		if(session.getAttribute("utenteLoggato")==null) {
			model.addAttribute("criteriUtente", new CriteriUtente());
			return "login";
		}
		@SuppressWarnings("unchecked")
		List<Prodotto> prodottiNelCarrello = (List<Prodotto>) session.getAttribute("prodottiNelCarrello");
		if (prodottiNelCarrello != null) {
			model.addAttribute("prodottiNelCarrello", prodottiNelCarrello);
		}
		return "carrello";
	}
	
	@GetMapping("/checkout")
	public String checkout(Model model, HttpSession session) {
		Integer userId;
		if((userId=(Integer)session.getAttribute("utenteLoggato"))==null) {
			model.addAttribute("criteriUtente", new CriteriUtente());
			return "login";
		}
		@SuppressWarnings("unchecked")
		List<Prodotto> prodottiNelCarrello = (List<Prodotto>) session.getAttribute("prodottiNelCarrello");
		
		if (prodottiNelCarrello != null) {

			Long idAcquisto = System.currentTimeMillis();
			Utente utente = utenteRepo.findUtentiByIdUtente(userId);
				
			Map<Integer, List<Prodotto>> prodottiMappati = prodottiNelCarrello.stream()
					.collect(Collectors.groupingBy(Prodotto::getIdProdotto));
			
			Iterator <Integer> it = prodottiMappati.keySet().iterator(); 

			Double prezzoTotale = 0.0;
			Double prezzoParziale = 0.0;
			int nPezzi = 0;
			while(it.hasNext()) {
				int x = it.next();
				Acquisto acquisto = new Acquisto();
				acquisto.setIdAcquisto(idAcquisto);
				acquisto.setUtente(utente);
				acquisto.setProdotto(prodottiMappati.get(x).get(0));
				nPezzi = prodottiMappati.get(x).size();
				acquisto.setnPezzi(nPezzi);
				prezzoParziale = prodottiMappati.get(x).size()*prodottiMappati.get(x).get(0).getPrezzo();
				acquisto.setTotaleAcquisto(prezzoParziale);
				acquistoRepo.save(acquisto);
				prezzoTotale += prezzoParziale;
			}
			
			List<Prodotto>listaProdotti = new ArrayList<>();
			listaProdotti.addAll(prodottiNelCarrello);
			model.addAttribute("listaProdotti", listaProdotti);
			model.addAttribute("totale", prezzoTotale);
			prodottiNelCarrello.clear();
		}
		return "checkout";
	}
	
	@GetMapping("/rimuovi")
	public String rimuovi(@Valid @ModelAttribute ("prodotto") Prodotto prodotto, Errors errors, Model model, HttpSession session) {
		if(session.getAttribute("utenteLoggato")==null) {
			model.addAttribute("criteriUtente", new CriteriUtente());
			return "login";
		}
		
		for(Prodotto prod : prodotti) {
			if(prodotto.getIdProdotto()==prod.getIdProdotto()) {
				prodotti.remove(prod);
				break;
			}
		}
		session.setAttribute("prodottiNelCarrello", prodotti);
		model.addAttribute("prodottiNelCarrello", prodotti);

		return "carrello";  
	}
}
