package ecommerce.controller;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.*;

import ecommerce.model.CriteriUtente;
import ecommerce.model.Prodotto;
import ecommerce.repository.ProdottoRepository;

@Controller
public class ProdottoController {
	
	@Autowired
	private ProdottoRepository prodottoRepo;

	@GetMapping("/inserisciProdotto")
	public String inserisciProdotto(Model model, HttpSession session) {
		if(session.getAttribute("utenteLoggato")==null) {
			model.addAttribute("criteriUtente", new CriteriUtente());
			return "login";
		}
		model.addAttribute("prodotto", new Prodotto());
		return "inserisciProdotto";
	}
	
	@PostMapping("/inserisciProdotto")
	public String inserisciProdotto(@Valid @ModelAttribute ("prodotto") Prodotto prodotto, Errors errors, Model model)  {
		if (errors.hasErrors()) {
			return "inserisciProdotto";
		}
		prodottoRepo.save(prodotto); 
		model.addAttribute("prodotto", prodotto);
		return "menuAdmin";  
	}
	
	@GetMapping("/visualizzaListaProdotti")
	public String visualizzaListaProdotti(Model model, HttpSession session) {
		if(session.getAttribute("utenteLoggato")==null) {
			model.addAttribute("criteriUtente", new CriteriUtente());
			return "login";
		}
		Iterable<Prodotto> prodotti = prodottoRepo.findAll();
		model.addAttribute("prodotti", prodotti);
		return "listaProdotti";
	}
	
	@GetMapping("/visualizzaListinoProdotti")
	public String visualizzaListinoProdotti(Model model, HttpSession session) {
		if(session.getAttribute("utenteLoggato")==null) {
			model.addAttribute("criteriUtente", new CriteriUtente());
			return "login";
		}
		Iterable<Prodotto> prodotti = prodottoRepo.findAll();
		model.addAttribute("prodotti", prodotti);
		return "listinoProdotti";
	}
}
