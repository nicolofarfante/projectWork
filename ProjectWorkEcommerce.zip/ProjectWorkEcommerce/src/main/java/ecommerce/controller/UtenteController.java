package ecommerce.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.*;

import ecommerce.model.CriteriUtente;
import ecommerce.model.Utente;
import ecommerce.repository.UtenteRepository;

@Controller
public class UtenteController {
	
	@Autowired
	private UtenteRepository utenteRepo;
	
	@GetMapping("/menuAdmin")
	public String vaiAMenuAdmin(Model model, HttpSession session) {
		if(session.getAttribute("utenteLoggato")==null) {
			model.addAttribute("criteriUtente", new CriteriUtente());
			return "login";
		}
		return "menuAdmin";
	}
	
	@GetMapping("/menuClienti")
	public String vaiAMenuClienti(Model model, HttpSession session) {
		if(session.getAttribute("utenteLoggato")==null) {
			model.addAttribute("criteriUtente", new CriteriUtente());
			return "login";
		}
		return "menuClienti";
	}
	
	@PostMapping("/loginUtente")
	public String loginUtente(@ModelAttribute ("criteriUtente") CriteriUtente criteriUtente, Errors errors, Model model, HttpSession session) {
		if(errors.hasErrors()) {
			return "login";
		}
		Utente utente = utenteRepo.findUtentiByUsernameAndPassword(criteriUtente.getUsername(), criteriUtente.getPassword());
		if(utente == null) {
			errors.rejectValue("password", "passwordErrata");
			return "login";
		}
		session.setAttribute("utenteLoggato", utente.getIdUtente());
		if (utente.isAdmin()) {
			return "menuAdmin";
		}
		else {
			return "menuClienti";
		}
	}    

}
