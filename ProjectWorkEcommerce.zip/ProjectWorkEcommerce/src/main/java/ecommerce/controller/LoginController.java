package ecommerce.controller;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import ecommerce.model.CriteriUtente;

@Controller
public class LoginController {
	@GetMapping("/")
	public String inviaLogin(Model model) {
		model.addAttribute("criteriUtente", new CriteriUtente());
		return "login";
	}
	
	@GetMapping("/logout")
	public String inviaLogout(Model model, HttpSession session) {
		model.addAttribute("criteriUtente", new CriteriUtente());
		model.addAttribute("logoutMessage", "logoutMessage");
		session.setAttribute("utenteLoggato", null);
		return "login";
	}
	
}
