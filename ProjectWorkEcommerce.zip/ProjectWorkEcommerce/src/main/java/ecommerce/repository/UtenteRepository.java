package ecommerce.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import ecommerce.model.Utente;

@Repository
public interface UtenteRepository extends CrudRepository<Utente, Integer> {

	Utente findUtentiByUsernameAndPassword(String username, String password);
	Utente findUtentiByIdUtente(int utenteId);
}
