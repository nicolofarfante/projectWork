package ecommerce.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import ecommerce.model.Acquisto;

@Repository
public interface AcquistoRepository extends CrudRepository<Acquisto, Integer> {

}
