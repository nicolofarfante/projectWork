package ecommerce.validator;

import java.text.DecimalFormat;

import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import ecommerce.model.Prodotto;


public class ProdottoValidator implements Validator {

	@Override
	public boolean supports(Class<?> clazz) {
		return Prodotto.class.isAssignableFrom(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		
		Prodotto prodotto = (Prodotto) target;
		DecimalFormat df = new DecimalFormat("###.##");

		if(!(prodotto.getPrezzo() == (Double.parseDouble(df.format(prodotto.getPrezzo()))))) {
			errors.rejectValue("prezzo", "decimaliSuperioriAlLimite");
		}

	}

}
