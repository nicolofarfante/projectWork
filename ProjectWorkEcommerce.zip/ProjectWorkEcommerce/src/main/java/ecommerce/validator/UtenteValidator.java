package ecommerce.validator;

import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import ecommerce.model.Utente;

public class UtenteValidator implements Validator {

	@Override
	public boolean supports(Class<?> clazz) {
		return Utente.class.isAssignableFrom(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {

		/*Utente utente = (Utente) target;

		if(!PASSWORD_PATTERN.matcher(utente.getPassword()).matches()) {
			errors.rejectValue("password", "formatoPasswordNonAmmesso");
		}*/
	}

}
